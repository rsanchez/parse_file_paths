<?php

return array(
  'author'      => 'Rob Sanchez - updated to work with v3.xx by Terry Britton',
  'author_url'  => 'https://github.com/rsanchez',
  'name'        => 'parse_file_paths',
  'description' => 'Parses {filedir_X} variables',
  'version'     => '2.0.0',
  'namespace'   => 'Utility\parse_file_paths'
);